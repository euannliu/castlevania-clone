EU-ANN LIU'S CLONE OF NES CASTLEVANIA
----
HOW TO PLAY:

You are Simon Belmont, here to slay the evil Count Dracula.
HOWEVER
Dracula has cursed his Castle so that you can only play the first stage.
Luckily, the Goddess of Light made it so that upon first stage completion,
you will destroy Dracula's Castle!
VICTORY.
You are here to jump, crouch, and attack, killing all enemies on sight.
Reach the end, grab the orb, and WIN THE GAME.
If you have trouble understanding what to do:
KEEP MOVING RIGHT (if you can, there's a part where you have to find a staircase
to go down somewhere)
AND KEEP KILLING THINGS

----
DIRECTIONS:

UP = Go up stairs
DOWN = Crouch / Go down stairs
LEFT = Move left
RIGHT = Move right

D = Jump
F = Attack with Whip

UP + F = Use Secondary Weapon

F1 = Full Screen / Windowed Mode Toggle

ENTER = Pause

M = ???
----
CHEATS:

I = Reset Timer
O = Gain Full Health
P = Reset Room (in case of glitch)

----
BUGS/DIFFERENCES:
1) Simon does not fall like he falls in the Castlevania NES game.
2) Simon does not jump like he jumps in Castlevania NES game
	(in NES game, Simon stays afloat a bit before coming down)
3) Two items were removed
	(Invisiblity Potion and the Cross)
4) Hidden Money Bag returns 
	(If you go back to the room with the fish, you can grab the hidden
	bag as many times as you want)
5) Meat returns
	(Same thing with Hidden Money)

----
SECONDARY WEAPON DIRECTORY:
Axe = Flies up in the air in an arc
Knife = Goes straight out in front of you
Holy Water = Creates a spot on the ground that burns with fire
"II" = Allows you to fire two secondary weapons at a time
